Need to install the following packages:
supabase@2.9.6
Ok to proceed? (y) 
