-- Add long_text_receipt column to receipts table
ALTER TABLE receipts
ADD COLUMN long_text_receipt TEXT;